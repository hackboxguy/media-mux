export DISPLAY=:0;/usr/bin/cvlc --video-on-top --fullscreen --extraintf http --http-password brb0x --control netsync --netsync-master > /dev/null
